class Variable {
	private String name;
	
	public Variable(String name) {
		this.name = name;
	}
	
	String get_name() {
		return name;
	}		
}
